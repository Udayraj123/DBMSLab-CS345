source 150101021.sql;
source 150101021_depts.sql;
source 150101021_rooms.sql;
source 150101021_slots.sql;
source 150101021_courses.sql;
source 150101021_sched.sql;